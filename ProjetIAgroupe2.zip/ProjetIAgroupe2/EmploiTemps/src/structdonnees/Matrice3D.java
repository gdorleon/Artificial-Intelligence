package structdonnees;

import java.util.Vector;

 public class Matrice3D<T> {
	private int P;
	private int R;
	private int C;
	private Vector<T> Data;
	private T temp;

	public Matrice3D(int P, int R, int C) {
		this.P = P;
		this.R = R;
		this.C = C;
		Data = new Vector<T>();
		Data.setSize(P * R * C);
	}

	public T getT(){
		return temp;
	}
	public int getP(){
		return P;
	}
	public int getR(){
		return R;
	}
	public int getC(){
		return C;
	}
	public void clearData() {
		Data.clear();
	}

	public Vector<T> getData() {
		return Data;
	}

	public T getData(int i, int j, int k) {

		return Data.get((((i * R) + j) * C) + k);
	}
	
	public void afficher() {

		for(int i=0;i<P;i++){

		 for(int j=0;j<R;j++){
		  for(int k=0;k<C;k++)
		   System.out.print(Data.get((((i * R) + j) * C) + k)+"\t");
		  System.out.print("\n");
		 }
		}
	}

	public void setContent(int i, int j, int k, T t) {
		// A[l][m][n];
		// A[i][j][k] -> (((i*m)+j)*n)+k
		Data.set((((i * R) + j) * C) + k,t);
	}
	
	public void Init(T t){
		this.temp=t;
		clearData();
		for(int i=0;i<P*R*C;i++)
			getData().add(i, t);
	}
	
	public Matrice2D<T> get2DPart(int i){
		Matrice2D<T> M2DForm;
		M2DForm = new Matrice2D<T>(R,C) ;
		M2DForm.DonneeInit(getT());
		for(int j=0;j<R;j++){
			for(int k=0;k<C;k++)
				M2DForm.setData(j, k, getData(i,j,k));
		}
		return M2DForm;
	}
	
	public void set2DPart(int i,Matrice2D<T> M2DForm){
		for(int j=0;j<M2DForm.getn();j++)
			for(int k=0;k<M2DForm.getp();k++)
				setContent(i,j,k,M2DForm.getData(j, k));
	}
}

