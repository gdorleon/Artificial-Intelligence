

package structdonnees;

import java.util.ArrayList;

public class EnsembleActivite {
	private int id;
	private String libelle;
	private String professeur;
	private String classe;
	private String cour;
	private String maisonSalle;
	private ArrayList<String> room;
	private int duree;

	public EnsembleActivite(int i){
		setId(i);
		room=new ArrayList<String>();
	}

	public void setMaisonSalle(String maisonSalle) {
		this.maisonSalle = maisonSalle;
	}

	public String getMaisonSalle() {
		return maisonSalle;
	}

	public ArrayList<String> getSalles() {
		return room;
	}

	public void setId(int i) {
		id = i;
	}

	public int getId() {
		return id;
	}

	public void setTag(String acttag) {
		libelle = acttag;
	}

	public String getTag() {
		return libelle;
	}

	public void setCour(String cours) {
		cour = cours;
	}

	public String getCour() {
		return cour;
	}

	public void setClasse(String classe) {
		this.classe=classe;
	}

	public String getClasse() {
		return classe;
	}

	public void setDuree(int Dur) {
		duree = Dur;
	}

	public int getDuree() {
		return duree;
	}
	
	public void setProfesseur(String prof) {
		professeur=prof;
	}

	public String getProfesseur() {
		return professeur;
	}

}
