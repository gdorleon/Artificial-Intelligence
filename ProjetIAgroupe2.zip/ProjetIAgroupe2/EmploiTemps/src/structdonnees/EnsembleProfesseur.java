package structdonnees;
/**
 * Donnes les informations sur un enseignant
 * @author gervais
 *
 */
public class EnsembleProfesseur {
	private String nom;
	private String type;

	public EnsembleProfesseur(String nom, String type) {
		this.nom = nom;
		this.type=type;
	}

	public String getNom() {
		return nom;
	}
	
	public String getType() {
		return type;
	}

	public void setNom(String s) {
		nom=s;
	}
	
	public void setType(String s) {
		type=s;
	}

	
}
