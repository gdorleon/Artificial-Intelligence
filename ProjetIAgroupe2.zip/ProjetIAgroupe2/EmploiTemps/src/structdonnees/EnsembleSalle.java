package structdonnees;

public class EnsembleSalle {
	private String nom;
	private int capacite;
	private String type;

	public EnsembleSalle(String nom, int capacite, String type) {
		this.nom = nom;
		this.type = type;
		this.capacite = capacite;
	}

	public String getNom() {
		return nom;
	}

	public String getType() {
		return type;
	}

	public int getCapacite() {
		return capacite;
	}

	public void setNom(String s) {
		nom = s;
	}

	public void setType(String s) {
		type = s;
	}

	public void setCapacite(int i) {
		capacite = i;
	}

}
