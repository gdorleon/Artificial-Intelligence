package structdonnees;

import java.util.Vector;
/**
 * 
 * @author gervais
 *Définie la liste des jours  et des tranches horaires dans une semaine
 */
public class EnsembleHoraire {

	private Vector<String> listeJours;
	private Vector<String> listeHeure;
	
	public EnsembleHoraire() {
		listeJours = new Vector<String>();
		listeHeure = new Vector<String>();
	}

	public Vector<String> getJours() {
		return listeJours;
	}

	public Vector<String> getHeure() {
		return listeHeure;
	}

}
