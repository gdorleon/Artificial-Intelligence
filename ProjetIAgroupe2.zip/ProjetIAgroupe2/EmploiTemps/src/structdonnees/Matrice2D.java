package structdonnees;

import java.util.Vector;

public class Matrice2D<T> {
	private int n;
	private int p;
	private Vector<T> Data;

	public Matrice2D(int n, int p) {
		this.n = n;
		this.p = p;
		Data = new Vector<T>();
		Data.setSize(n * p);
	}

	public int getn() {
		return n;
	}

	public int getp() {
		return p;
	}

	public void effacerData() {
		Data.clear();
	}

	public Vector<T> getData() {
		return Data;
	}

	public T getData(int i, int j) {
		// A[m][n];
		// A[i][j] -> (i*n)+j
		// System.out.println( "["+ String.valueOf(i)+ Data.get((i * p) + j)
		// + String.valueOf(j)+"]");
		return Data.get((i * p) + j);
	}

	public void setData(int i, int j, T t) {
		// A[l][m][n];
		// A[i][j][k] -> (((i*m)+j)*n)+k
		Data.set((i * p) + j, t);
	}

	public void DonneeInit(T t) {
		effacerData();
		for (int i = 0; i < n * p; i++)
			getData().add(i, t);
	}

	public void imprimer() {
		 for (int j = 0; j < p; j++){
			for (int i = 0; i < n; i++)
				System.out.print(Data.get((i * p) + j) + "{//\\\\}");
			System.out.print("\n");
		}

	}
}
