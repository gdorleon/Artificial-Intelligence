package structdonnees;

public class EnsembleCour {
	private int nbreTheo = 0;
	private int nbrePratiq = 0;
	private String nom;

	public EnsembleCour(String nomm, int ntheo, int nPra) {
		nbreTheo = nPra;
		nbrePratiq = ntheo;
		nom = nomm;
	}

	public String getNom() {
		return nom;
	}

	public int getNBreTheo() {
		return nbreTheo;
	}

	public int getnbrePrati() {
		return nbrePratiq;
	}

	public void setNom(String s) {
		nom=s;
	}

	public void setNbreTheo(int i) {
		nbreTheo=i;
	}

	public void setNBrePratiqu(int i) {
		nbrePratiq=i;
	}
}