package structdonnees;

import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;

import donnees.AssignationCours;
import emploitemps.Contraintes;




public class EnsembeDonnees {
	private ArrayList<EnsembleSalle> listeSalle;
	private ArrayList<EnsembleCour> listeCours;
	private ArrayList<EnsembleProfesseur> listeProf;
	private ArrayList<EnsembleClasse> listeClasse;
	private ArrayList<EnsembleActivite> listeActivite;
	private ArrayList<AssignationCours> assigneCourProf;
	private Contraintes contrainteListe;
	private EnsembleHoraire ensembleHoraire;

	private boolean misAjour;
	private int TH,PR; 

	public static final int MAXSUBJECT = 150; 
	public static final int MAXSTUDENT = 50; 
	public static final int MAXTEACHER = 150; 
	public static final int MAXROOM = 50;
	public static final int MAXDAY = 6; 
	public static final int MAXHOUR = 12;

	public static final int SUBJECT = 0; 
	public static final int STUDENT = 1; 
	public static final int TEACHER = 2; 
	public static final int ROOM = 3; 
	public static final int TIME = 4; 
	public static final int ACTIVITY = 5; 
	public static final int ASSIGNSUBJECT = 6; 
	public static final int DATA_NAME = 0; 
	public static final int DATA_TYPE = 1; 
	public static final int DATA_CAPACITY = 2;
	public static final int DATA_NOT = 3; 
	public static final int DATA_NOP = 4; 
	public static final int DATA_STRENGTH = 5; 
	public static final int ID = 6; 

	public EnsembeDonnees() {
		misAjour = true;
		listeSalle = new ArrayList<EnsembleSalle>();
		listeCours = new ArrayList<EnsembleCour>();
		listeProf = new ArrayList<EnsembleProfesseur>();
		listeClasse = new ArrayList<EnsembleClasse>();
		listeActivite = new ArrayList<EnsembleActivite>();
		assigneCourProf = new ArrayList<AssignationCours>();
		contrainteListe =new Contraintes();
		ensembleHoraire = new EnsembleHoraire();
	}

	public void setTheoPrat(int TH,int PR) {
		this.TH = TH;
		this.PR = PR;
	}

	public int getTheoPrat() {
		return TH;
	}

	public int getPRat() {
		return PR;
	}

	public boolean getStatus() {
		return misAjour;
	}

	public void setStatus(boolean status) {
		misAjour = status;
	}

	public EnsembleHoraire getCreneaux() {
		return ensembleHoraire;
	}

	// classe////////////////////////////////////////////////

	public EnsembleClasse getClasse(int i) {
		return listeClasse.get(i);
	}

	public int trouverClasse(String nom) {
		for (int i = 0; i < listeClasse.size(); i++)
			if (listeClasse.get(i).getNom().equalsIgnoreCase(nom))
				return i;
		return -1;
	}

	public int trouverGroupeEleve(int i, String name) {
		EnsembleClasse temp = getClasse(i);
		for (int j = 0; j < temp.getListeGroupe().size(); j++)
			if (temp.getListeGroupe().get(j).getNom().equalsIgnoreCase(name))
				return j;
		return -1;
	}

	public EnsembleClasse chercherGroupEleve(EnsembleClasse temp, String name) {
		for (int i = 0; i < temp.getListeGroupe().size(); i++)
			if (temp.getListeGroupe().get(i).getNom().equalsIgnoreCase(name))
				return temp.getListeGroupe().get(i);
		return null;
	}

	public void retirerClasse(int pos) {
		listeClasse.remove(pos);
	}

	public void enleverGroupe(int pos, int gpos) {
		int gs =listeClasse.get(pos).getGroupTaille(gpos);
		listeClasse.get(pos).setLimiteGroupe(gs);
		listeClasse.get(pos).getListeGroupe().remove(gpos);
		
	}

	public void ajouterClasse(String name, int strength) {
		if (trouverClasse(name) == -1) {
			listeClasse.add(new EnsembleClasse(name, strength));
			setStatus(false);
		} else
			JOptionPane.showMessageDialog(null, "Dupliqué : " + name,
					"Dupliqué", JOptionPane.INFORMATION_MESSAGE);
	}

	public boolean ajouterGroupe(String Name, String GName, int Strength) {
		int i = trouverClasse(Name);
		EnsembleClasse temp = getClasse(i);
		if (temp != null) {
			System.out.println(temp.getTotStud() + ":" + temp.getLimiteGroupe());
			if (trouverGroupeEleve(i, GName) == -1) {
				if (Strength <= (temp.getTotStud() - temp.getLimiteGroupe())) {
					temp.getListeGroupe().add(new EnsembleClasse(GName, Strength));
					temp.setLimiteGroupe(Strength);
					setStatus(false);
					return true;
				} else
					JOptionPane
							.showMessageDialog(null,
									"La taille d'un groupe "
											+ " \n doit être plus petite que "
											+ (temp.getTotStud() - temp
													.getLimiteGroupe()),
									"Taille de groupe dépassée!",
									JOptionPane.ERROR_MESSAGE);
			} else
				JOptionPane.showMessageDialog(null, "Entrée dupliquée : "
						+ GName, "Dupliquée", JOptionPane.INFORMATION_MESSAGE);

		} else
			JOptionPane.showMessageDialog(null, Name
					+ " Non disponible, le groupe ne peux être crée", "Erreur groupe!",
					JOptionPane.ERROR_MESSAGE);
		return false;
	}

	public int getLongueurTouteCLasses() {
		int size = 0;
		for (int i = 0; i < listeClasse.size(); i++) {
			size += listeClasse.get(i).getListeGroupe().size()+1;
		}
		return size;
	}

	public int getLongueurClasse() {
		return listeClasse.size();
	}

	public Object[] getClasseEnregistrement(int i) {
		Object[] obj = { listeClasse.get(i).getNom(),
				listeClasse.get(i).getTotStud() };
		return obj;
	}

	public Object[] getGroupeEleve(int i, int j) {
		Object[] obj = { listeClasse.get(i).getListeGroupe().get(j).getNom(),
				listeClasse.get(i).getListeGroupe().get(j).getTotStud() };
		return obj;
	}

	// professeur///////////////////////////////////////////////

	public EnsembleProfesseur getProfesseur(int i) {
		return listeProf.get(i);
	}

	public int chercherProfesseur(String name) {
		for (int i = 0; i < listeProf.size(); i++)
			if (listeProf.get(i).getNom().equalsIgnoreCase(name))
				return i;
		return -1;
	}

	public void enleverProfesseur(int pos) {
		listeProf.remove(pos);
	}

	public void ajouterProfesseur(String name, String type) {
		if (chercherProfesseur(name) == -1) {
			listeProf.add(new EnsembleProfesseur(name, type));
			setStatus(false);
		} else
			JOptionPane.showMessageDialog(null, "Dupliqué: " + name,
					"dupliqué", JOptionPane.INFORMATION_MESSAGE);
	}

	public int getPROFTaille() {
		return listeProf.size();
	}

	public Object[] getProfesseurENregis(int i) {
		Object[] obj = { listeProf.get(i).getNom(),
				listeProf.get(i).getType() };
		return obj;
	}

	// Matière////////////////////////////////////////////////

	public EnsembleCour getSubject(int i) {
		return listeCours.get(i);
	}

	public int searchSubject(String name) {
		for (int i = 0; i < listeCours.size(); i++)
			if (listeCours.get(i).getNom().equalsIgnoreCase(name))
				return i;
		return -1;
	}

	public void enleverCours(int pos) {
		listeCours.remove(pos);
	}

	public void addCours(String name, int noT, int noP) {
		if (searchSubject(name) == -1) {
			listeCours.add(new EnsembleCour(name, noT, noP));
			setStatus(false);
		} else
			JOptionPane.showMessageDialog(null, "Duplicate Entry : " + name,
					"Duplicate", JOptionPane.INFORMATION_MESSAGE);
	}

	public int getCoursLongueur() {
		return listeCours.size();
	}

	public Object[] getCourListe(int i) {
		Object[] obj = { listeCours.get(i).getNom(),
				listeCours.get(i).getnbrePrati(), listeCours.get(i).getNBreTheo() };

		return obj;
	}

	// salle////////////////////////////////////////////////

	public EnsembleSalle getSalle(int i) {
		return listeSalle.get(i);
	}

	public int chercherSalle(String name) {
		for (int i = 0; i < listeSalle.size(); i++)
			if (listeSalle.get(i).getNom().equalsIgnoreCase(name))
				return i;
		return -1;
	}

	public void enleverSaller(int pos) {
		listeSalle.remove(pos);
	}

	public void ajouterSalle(String name, int capacity, String type) {
		if (chercherSalle(name) == -1) {
			listeSalle.add(new EnsembleSalle(name, capacity, type));
			setStatus(false);
		} else
			JOptionPane.showMessageDialog(null, "Entrée dupliquée : " + name,
					"Duplicate", JOptionPane.INFORMATION_MESSAGE);
	}

	public int getLongueurSalle() {
		return listeSalle.size();
	}

	public Object[] getSalleListe(int i) {
		Object[] obj = { listeSalle.get(i).getNom(), listeSalle.get(i).getType(),
				listeSalle.get(i).getCapacite() };
		return obj;
	}

	// Activité////////////////////////////////////////////////

	public ArrayList<EnsembleActivite> getListeActivite() {
		return listeActivite;
	}

	public void enleverActivite(int pos) {
		listeActivite.remove(pos);
	}

	public void ajouterActivite(int i,EnsembleActivite act) {
		listeActivite.add(i, act);
		setStatus(false);
	}

	public EnsembleActivite getActivite(int i) {
		return listeActivite.get(i);
	}

	public int getLongueurActivite() {
		return listeActivite.size();
	}

	public Object[] getListeActivite(int i) {
		Object[] obj = { "ID :"+ listeActivite.get(i).getId(),
				"Tag :"+ listeActivite.get(i).getTag(), 
				"Subject :"+ listeActivite.get(i).getCour(), 
				"Student :"+ listeActivite.get(i).getClasse(), 
				"Teacher :"+ listeActivite.get(i).getProfesseur(),
				"Duration :"+ listeActivite.get(i).getDuree()
				 };

		return obj;
	}

	// AssignationCours////////////////////////////////////////////////

	public ArrayList<AssignationCours> getListeAssigneCours() {
		return assigneCourProf;
	}

	public AssignationCours getCoursAssigne(int i) {
		return assigneCourProf.get(i);
	}

	public int chercherCoursAssignes(String name) {
		for (int i = 0; i < getLongueurCourAssigne(); i++)
			if (assigneCourProf.get(i).getSubj().getNom().equals(name))
				return i;
		return -1;
	}

	public int getLongueurCourAssigne() {
		return assigneCourProf.size();
	}

	public String getMatiereTheorique(int i) {
		String obj = "[Cour : " + assigneCourProf.get(i).getSubj().getNom()
				+ "]";
		obj += "[TH: ";
		obj += "[Enseignant : " + assigneCourProf.get(i).getTchTH() + "]";
		obj += "[Groupe : " + assigneCourProf.get(i).getStudTH() + "]";
		return obj;
	}

	public String getMatierePratique(int i) {
		String obj = "[PR: ";

		for (int j = 0; j < assigneCourProf.get(i).getTchPR().size(); j++)
			obj += "[Enseignant : " + assigneCourProf.get(i).getTchPR().get(j) + "]";

		for (int j = 0; j < assigneCourProf.get(i).getStudPR().size(); j++)
			obj += "[Groupe : " + assigneCourProf.get(i).getStudPR().get(j)
					+ "]";
		return obj;
	}

	public void copierCOur() {
		
		for (int i = 0; i < getCoursLongueur(); i++) {
			if (assigneCourProf.size() <= i) {
				AssignationCours temp = new AssignationCours();
				temp.setSubj(getSubject(i));
				assigneCourProf.add(i, temp);
				System.out.println("i::" + i);
			}
		}
	}

	public void miseAjourMatiereAssigne() {
		for (int i = 0; i < getLongueurCourAssigne(); i++) {
			AssignationCours temp = assigneCourProf.get(i);

			if(searchSubject(temp.getSubj().getNom())==-1)
				assigneCourProf.remove(i);
			else{
								
				if(temp.getStudTH()!=null)
				if(trouverClasse(temp.getStudTH())==-1){
					miseAjour(temp.getStudPR(),0);
					temp.setStudTH(null);
				}
				
				if(temp.getTchTH()!=null)
				if(chercherProfesseur(temp.getTchTH())==-1)
					temp.setTchTH(null);
				miseAjour(temp.getTchPR(),1);
			}
		}
	}

	public void miseAjour(ArrayList<String> str,int t) {
		for (int i = 0; i < str.size(); i++){
			switch(t){
			case 0:
				str.clear();
				break;
			case 1:
				if(chercherProfesseur(str.get(i))==-1)	
				   str.remove(i);
				break;
			}
		}
	}
	
	public boolean estAJour(){
		if(getLongueurCourAssigne()==0)
			return false;
		for (int i = 0; i < getLongueurCourAssigne(); i++) {
			AssignationCours temp = assigneCourProf.get(i);
			int index=searchSubject(temp.getSubj().getNom());

			if(index==-1)
				return false;
			else{

				if(getSubject(index).getnbrePrati()>0)
				if((temp.getStudTH()==null) || (temp.getTchTH()==null))
					return false;
				
				if(temp.getStudTH()!=null)
				if(trouverClasse(temp.getStudTH())==-1)
					return false;
				if(temp.getTchTH()!=null)
				if(chercherProfesseur(temp.getTchTH())==-1)
					return false;
			}
		}		
		return true;
	}


	public Vector<String> getNomProf() {
		Vector<String> names = new Vector<String>();
		for(int i=0;i<getPROFTaille();i++)
			names.add(i, getProfesseur(i).getNom());
		return names;
	}

	public Vector<String> getNomClasse() {
		Vector<String> names = new Vector<String>();
		for(int i=0,k=0;i<getLongueurClasse();i++){
			names.add(k++, getClasse(i).getNom());
			for(int j=0;j<getClasse(i).getListeGroupe().size();j++)
				names.add(k++, getClasse(i).getNomGroupe(j));
		}
		return names;
	}

	public Vector<String> getNomSalle() {
		Vector<String> names = new Vector<String>();
		for(int i=0;i<getLongueurSalle();i++)
			names.add(i, getSalle(i).getNom());
		return names;
	}

	/////////////////////////////////////////////////////////////////

	public Contraintes getContrainte() {
		return contrainteListe;
	}

}
