package structdonnees;

import java.util.ArrayList;
import javax.swing.JOptionPane;
/***
 * Cette classe représente une classe c'est à dire un groupe d'étudiant qui partagent les mêmes cours
 * @author gervais
 *
 */
public class EnsembleClasse {
	private String nom;
	private int toCours, limiteGroupe;
	private ArrayList<EnsembleClasse> listeGroupe;

	public EnsembleClasse(String nomm, int fors) {
		nom = nomm;
		toCours = fors;
		limiteGroupe = 0;
		listeGroupe = new ArrayList<EnsembleClasse>();
	}

	public ArrayList<EnsembleClasse> getListeGroupe() {
		return listeGroupe;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String s) {
		nom = s;
	}

	public int getTotStud() {
		return toCours;
	}

	public void setTotStud(int size) {
		if (size < toCours)
			modifierTailleGroupe(toCours - size);
		toCours = size;
	}

	private void modifierTailleGroupe(int d) {
		for (int i = 0; i < listeGroupe.size(); i++) {
			int s = listeGroupe.get(i).getTotStud();
			if ((s - d) > 0) {
				listeGroupe.get(i).setTotStud(s - d);
				return ;
			}
		}
	}

	public int getLimiteGroupe() {
		return limiteGroupe;
	}

	public void setLimiteGroupe(int i) {
		limiteGroupe += i;
	}

	public String getNomGroupe(int gno) {
		return listeGroupe.get(gno).getNom();
	}

	public void setGroupNom(int gno, String s) {
		listeGroupe.get(gno).setNom(s);
	}

	public int getGroupTaille(int gno) {
		return listeGroupe.get(gno).getTotStud();
	}

	public void setGroupeTaille(int gno, int i) {
		if (i != getGroupTaille(gno)) {
			if (i <= (toCours - limiteGroupe + getGroupTaille(gno))) {
				setLimiteGroupe(i - getGroupTaille(gno));
				listeGroupe.get(gno).setTotStud(i);
			} else
				JOptionPane.showMessageDialog(null," La taille du groupd doit etre plus  petite que:"
						+ gno + " \ndoit etre plus petite forc:"
						+ (toCours - limiteGroupe + getGroupTaille(gno)),
						"Taille du groupd depassées!", JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
