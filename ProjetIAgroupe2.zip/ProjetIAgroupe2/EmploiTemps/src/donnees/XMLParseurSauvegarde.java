package donnees;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import structdonnees.EnsembleActivite;
import structdonnees.EnsembeDonnees;
import structdonnees.EnsembleSalle;
import structdonnees.EnsembleClasse;
import structdonnees.EnsembleCour;
import structdonnees.EnsembleProfesseur;
/**
 * 
 * @author gervais
 * Cette classe est utilisé pour parser le fichier xml
 *
 */

public class XMLParseurSauvegarde {
	public static final String ext = ".edt.xml";
	DocumentBuilderFactory documentBuilderFactory;
	DocumentBuilder documentBuilder;
	Document document;

	Element rootElement;
	Element dayElement;
	Element hourElement;
	Element teacherElement;
	Element subjectElement;
	Element subjectAllocElement;
	Element studentElement;
	Element roomElement;
	Element activityElement;

	public XMLParseurSauvegarde() {

	}

	public void newXEDTM() {
		try {
			documentBuilderFactory = DocumentBuilderFactory.newInstance();
			documentBuilder = documentBuilderFactory.newDocumentBuilder();
			document = documentBuilder.newDocument();
			rootElement = document.createElement("edt");
			dayElement = document.createElement("Days_List");
			hourElement = document.createElement("Hours_List");
			teacherElement = document.createElement("Teachers_List");
			subjectElement = document.createElement("Subjects_List");
			subjectAllocElement = document.createElement("Subjects_Alloc_List");
			studentElement = document.createElement("Students_List");
			roomElement = document.createElement("Rooms_List");
			activityElement = document.createElement("Activity_List");
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}
// enregistrer les données recupérées dans le fichier XML
	public void SaveKB(String XMLFile, EnsembeDonnees ds) {

		for (int i = 0; i < ds.getCreneaux().getJours().size(); i++) {
			Element em = document.createElement("Day");
			em.appendChild(AddElement(ds.getCreneaux().getJours().get(i),EnsembeDonnees.DATA_NAME));
			AddKBElement("Day", em);
		}
		for (int i = 0; i < ds.getCreneaux().getHeure().size(); i++) {
			Element em = document.createElement("Hour");
			em.appendChild(AddElement(ds.getCreneaux().getHeure().get(i),EnsembeDonnees.DATA_NAME));
			AddKBElement("Hour", em);
		}
		for (int i = 0; i < ds.getPROFTaille(); i++) {
			EnsembleProfesseur temp=ds.getProfesseur(i);
			AddKBElement("Teacher", AddTeacherKB(temp));
		}
		for (int i = 0; i < ds.getCoursLongueur(); i++) {
			EnsembleCour temp=ds.getSubject(i);
			AddKBElement("Subject", AddSubjectKB(temp));
		}
		for (int i = 0; i < ds.getLongueurClasse(); i++) {
			EnsembleClasse temp=ds.getClasse(i);
			AddKBElement("Student", AddStudentKB(temp,true));
		}
		for (int i = 0; i < ds.getLongueurSalle(); i++) {
			EnsembleSalle temp=ds.getSalle(i);
			AddKBElement("Room", AddRoomKB(temp));
		}
		for (int i = 0; i < ds.getLongueurCourAssigne(); i++) {
			AssignationCours temp=ds.getCoursAssigne(i);
			AddKBElement("SubjectAlloc", AddSubjectAllocKB(temp));
		}
		for (int i = 0; i < ds.getLongueurActivite(); i++) {
			EnsembleActivite temp=ds.getActivite(i);
			AddKBElement("Activity", AddActivityKB(temp));
		}


		try {
			rootElement.setAttribute("College_Name", ds.getContrainte().getCollageName());
			rootElement.setAttribute("Department_Name", ds.getContrainte().getDeptName());
			rootElement.appendChild(dayElement);
			rootElement.appendChild(hourElement);
			rootElement.appendChild(studentElement);
			rootElement.appendChild(teacherElement);
			rootElement.appendChild(subjectElement);
			rootElement.appendChild(roomElement);
			rootElement.appendChild(subjectAllocElement);
			rootElement.appendChild(activityElement);

			document.appendChild(rootElement);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer;
			transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(document);
			if (XMLFile.endsWith(ext)){
				StreamResult result = new StreamResult(XMLFile);
				transformer.transform(source, result);				
			}
			else{
				StreamResult result = new StreamResult(XMLFile+ext);
				transformer.transform(source, result);				
			}
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}

	}
	
	public Element AddTeacherKB(EnsembleProfesseur teacher) {
		Element em = document.createElement("Teacher");
		em.appendChild(AddElement(teacher.getNom(),EnsembeDonnees.DATA_NAME));
		em.appendChild(AddElement(teacher.getType(),EnsembeDonnees.DATA_TYPE));
		return em;
	}
		
	public Element AddRoomKB(EnsembleSalle room) {
		Element em = document.createElement("Room");
		em.appendChild(AddElement(room.getNom(),EnsembeDonnees.DATA_NAME));
		em.appendChild(AddElement(room.getType(),EnsembeDonnees.DATA_TYPE));
		em.appendChild(AddElement(String.valueOf(room.getCapacite()), EnsembeDonnees.DATA_CAPACITY));
		return em;
	}
		
	public Element AddSubjectKB(EnsembleCour subj) {
		Element em = document.createElement("Subject");
		em.appendChild(AddElement(subj.getNom(),EnsembeDonnees.DATA_NAME));
		em.appendChild(AddElement(String.valueOf(subj.getnbrePrati()), EnsembeDonnees.DATA_NOT));
		em.appendChild(AddElement(String.valueOf(subj.getNBreTheo()), EnsembeDonnees.DATA_NOP));
		return em;
	}
	
	public Element AddSubjectAllocKB(AssignationCours subj) {
		Element em = document.createElement("SubjectAlloc");
		Element em1 = document.createElement("Theory");
		Element em2 = document.createElement("Practical");

		em1.appendChild(AddElement(subj.getTchTH(), "Teacher"));
		em1.appendChild(AddElement(subj.getStudTH(), "Student"));

		for(int i=0;i<subj.getTchPR().size();i++)
			  em2.appendChild(AddElement(subj.getTchPR().get(i), "Teacher"));
		for(int i=0;i<subj.getStudPR().size();i++)
			  em2.appendChild(AddElement(subj.getStudPR().get(i), "Student"));

		em.appendChild(AddElement(subj.getSubj().getNom(),EnsembeDonnees.DATA_NAME));
		
		if(subj.getSubj().getnbrePrati()>0)
		em.appendChild(em1);
		if(subj.getSubj().getNBreTheo()>0)
		em.appendChild(em2);
		return em;
	}
	
	public Element AddActivityKB(EnsembleActivite act) {
		Element em = document.createElement("Activity");
		em.setAttribute("ID",String.valueOf(act.getId()) );
		em.setAttribute("Tag", act.getTag());
		em.setAttribute("Subject", act.getCour());
		em.setAttribute("Student", act.getClasse());
		em.setAttribute("Teacher", act.getProfesseur());
		em.setAttribute("Duration", String.valueOf(act.getDuree()));

		String roomName="";
		if(act.getTag().equals("TH")){
			roomName=act.getMaisonSalle();
			em.appendChild(AddElement(roomName, "Room"));
		}
		else if(act.getTag().equals("PR")){
			for(int i=0;i<act.getSalles().size();i++){
				roomName=act.getSalles().get(i);
				em.appendChild(AddElement(roomName, "Room"));
			}
		}
		return em;
	}
	
	public Element AddStudentKB(EnsembleClasse stud, boolean b) {
		Element em = document.createElement("Student");
		em.appendChild(AddElement(stud.getNom(),EnsembeDonnees.DATA_NAME));
		em.appendChild(AddElement(String.valueOf(stud.getTotStud()), EnsembeDonnees.DATA_STRENGTH));
		if(b)
		for (int j = 0; j < stud.getListeGroupe().size(); j++) {
			EnsembleClasse gtemp=stud.getListeGroupe().get(j);
			Element group = document.createElement("Group");
			group.setAttribute("ID",String.valueOf(j));
			group.appendChild(AddElement(gtemp.getNom(),EnsembeDonnees.DATA_NAME));
			group.appendChild(AddElement(String.valueOf(gtemp.getTotStud()), EnsembeDonnees.DATA_STRENGTH));
			em.appendChild(group);
		}
		return em;
	}
	
	public Element AddElement(String name, String caption) {
		Element em;
		if(name==null)
			name="-Pas encore alloué-";
		em = document.createElement(caption);
		em.appendChild(document.createTextNode(name));
		return em;
	}
	
	public Element AddElement(String name, int data) {
		Element em;
		switch (data) {
		case EnsembeDonnees.DATA_NAME:
			em = document.createElement("Name");
			em.appendChild(document.createTextNode(name));
			return em;
		case EnsembeDonnees.DATA_TYPE:
			em = document.createElement("Type");
			em.appendChild(document.createTextNode(name));
			return em;
		case EnsembeDonnees.DATA_CAPACITY:
			em = document.createElement("Capacity");
			em.appendChild(document.createTextNode(name));
			return em;
		case EnsembeDonnees.DATA_NOT:
			em = document.createElement("No_Theory");
			em.appendChild(document.createTextNode(name));
			return em;
		case EnsembeDonnees.DATA_NOP:
			em = document.createElement("No_Practical");
			em.appendChild(document.createTextNode(name));
			return em;
		case EnsembeDonnees.DATA_STRENGTH:
			em = document.createElement("Strength");
			em.appendChild(document.createTextNode(name));
			return em;
		default:
		}
		return null;
	}

	public void AddKBElement(String ele, Element em) {
		if (ele.equalsIgnoreCase("professeur"))
			teacherElement.appendChild(em);
		else if (ele.equalsIgnoreCase("subject"))
			subjectElement.appendChild(em);
		else if (ele.equalsIgnoreCase("subjectalloc"))
			subjectAllocElement.appendChild(em);
		else if (ele.equalsIgnoreCase("classe"))
			studentElement.appendChild(em);
		else if (ele.equalsIgnoreCase("salle"))
			roomElement.appendChild(em);
		else if (ele.equalsIgnoreCase("jour"))
			dayElement.appendChild(em);
		else if (ele.equalsIgnoreCase("heure"))
			hourElement.appendChild(em);
		else if (ele.equalsIgnoreCase("activity"))
			activityElement.appendChild(em);
	}

}
