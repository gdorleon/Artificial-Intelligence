package donnees;

import gui.EDTModule;
import gui.PrincipalGUI;

import java.io.*;
import java.util.Iterator;
import java.util.List;

import org.dom4j.*;
import org.dom4j.io.SAXReader;




public class LireFichierXML extends EDTModule {
	private static final long serialVersionUID = 1L;

	public LireFichierXML(PrincipalGUI principalGUI) {
		super(principalGUI, "", "");
	}

	@SuppressWarnings("unchecked")
	public void readData(String filename) {
		setEDTData();
		Document doc;

		try {
			List<Element> innerEle;
			List<Element> groupElements;
			doc = new SAXReader().read(new File(filename));
			String _collageName =doc.getRootElement().attributeValue("College_Name");
			String _deptName =doc.getRootElement().attributeValue("Department_Name");
			getEDTData().getContrainte().setUniversite(_collageName);
			getEDTData().getContrainte().setDepartement(_deptName);
			System.out.println(_collageName);
			System.out.println(_deptName);
			XPath catPath = DocumentHelper.createXPath("//Teachers_List/Teacher");
			List<Element> catElements = catPath.selectNodes(doc);
			for (Iterator<Element> it = catElements.iterator(); it.hasNext();) {
				Element element = it.next();
				getEDTData().ajouterProfesseur(element.elementText("Name"),
						element.elementText("Type"));
			}

			catPath = DocumentHelper.createXPath("//Subjects_List/Subject");
			catElements = catPath.selectNodes(doc);
			for (Iterator<Element> it = catElements.iterator(); it.hasNext();) {
				Element element = it.next();
				getEDTData().addCours(element.elementText("Name"),
						Integer.parseInt(element.elementText("No_Theory")),
						Integer.parseInt(element.elementText("No_Practical")));
			}

			catPath = DocumentHelper.createXPath("//Students_List/Student");
			catElements = catPath.selectNodes(doc);
			for (Iterator<Element> it = catElements.iterator(); it.hasNext();) {
				Element element = it.next();
				getEDTData().ajouterClasse(element.elementText("Name"),
						Integer.parseInt(element.elementText("Strength")));

				if (element.element("Group") != null) {
					groupElements = element.elements("Group");
					for (Iterator<Element> itg = groupElements.iterator(); itg.hasNext();) {
						Element Gelement = itg.next();
						//System.out.println(Gelement.getName());
						getEDTData().ajouterGroupe(element.elementText("Name"),Gelement.elementText("Name"),Integer.parseInt(Gelement.elementText("Strength")));
					}
				}
			}

			catPath = DocumentHelper.createXPath("//Subjects_Alloc_List/SubjectAlloc");
			catElements = catPath.selectNodes(doc);

			if(getEDTData().getLongueurCourAssigne()<getEDTData().getCoursLongueur())
				getEDTData().copierCOur();
			int subjlen=0;
			int PR=0,TH=0;
			String s;
			for ( Iterator<Element> it = catElements.iterator(); it.hasNext();subjlen++) {
				Element element = it.next();
				String Subj=element.elementText("Name");
				//System.out.println(Subj);

				if (element.element("Theory") != null) {
					TH+=getEDTData().getSubject(subjlen).getnbrePrati();
					Element Nelement = element.element("Theory");
					s=Nelement.elementText("Teacher");
					getEDTData().getCoursAssigne(subjlen).setTchTH(s);
					//System.out.println("TH "+Nelement.elementText("Teacher"));
					
					s=Nelement.elementText("Student");
					getEDTData().getCoursAssigne(subjlen).setStudTH(s);
					//System.out.println("TH "+Nelement.elementText("Student"));
				}
				
				if (element.element("Practical") != null) {
					groupElements = element.elements("Practical");
					for (Iterator<Element> itn = groupElements.iterator(); itn.hasNext();) {
						Element Nelement = itn.next();	
						innerEle=Nelement.elements("Teacher");
						for(int i=0;i<innerEle.size();i++){
							s=innerEle.get(i).getText();
							getEDTData().getCoursAssigne(subjlen).getTchPR().add(s);
					
						}
						innerEle=Nelement.elements("Student");
						for(int i=0;i<innerEle.size();i++){
							PR++;
							s=innerEle.get(i).getText();
							getEDTData().getCoursAssigne(subjlen).getStudPR().add(s);
					
						}						
					}
				}
			}
			getEDTData().setTheoPrat(TH, PR);
			System.out.println(getEDTData().getPRat()+":0:"+getEDTData().getTheoPrat());

			catPath = DocumentHelper.createXPath("//Rooms_List/Room");
			catElements = catPath.selectNodes(doc);
			for (Iterator<Element> it = catElements.iterator(); it.hasNext();) {
				Element element = it.next();
				getEDTData().ajouterSalle(element.elementText("Name"),
						Integer.parseInt(element.elementText("Capacity")),
						element.elementText("Type"));
			}

			catPath = DocumentHelper.createXPath("//Days_List/Day");
			catElements = catPath.selectNodes(doc);
			for (Iterator<Element> it = catElements.iterator(); it.hasNext();) {
				Element element = it.next();
				getEDTData().getCreneaux().getJours().add(
						element.elementText("Name"));
			}

			catPath = DocumentHelper.createXPath("//Hours_List/Hour");
			catElements = catPath.selectNodes(doc);
			for (Iterator<Element> it = catElements.iterator(); it.hasNext();) {
				Element element = it.next();
				getEDTData().getCreneaux().getHeure().add(
						element.elementText("Name"));
			}

		} catch (DocumentException e) {
			e.printStackTrace();
		}
		
	}
		
}
