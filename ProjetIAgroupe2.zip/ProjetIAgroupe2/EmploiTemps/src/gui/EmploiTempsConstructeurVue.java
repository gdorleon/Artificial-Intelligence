package gui;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import structdonnees.EnsembeDonnees;
import emploitemps.GenerateurResultat;



public class EmploiTempsConstructeurVue extends EDTModule implements ActionListener {
	private JTabbedPane tabbedpane;
	private ViewPanel TchTablePanel, StudTablePanel, Stud1TablePanel, RoomTablePanel;
	private GenerateurResultat og;
	/**
	 * EmploiTempsConstructeurVue Construit l'interface graphique de l'emploi du temps
	 */
	public EmploiTempsConstructeurVue(PrincipalGUI principalGUI) {

		super(principalGUI, "EmploiTempsConstructeurVue", "edt.png");


		tabbedpane = new JTabbedPane();
		getMenuPanel().add(tabbedpane, BorderLayout.CENTER);

		

		String name = getString("EmploiTempsConstructeurVue.prof");
		TchTablePanel = new ViewPanel(name);
		tabbedpane.add(name, TchTablePanel);

		name = getString("EmploiTempsConstructeurVue.classe");
		StudTablePanel = new ViewPanel(name);
		tabbedpane.add(name, StudTablePanel);

		name = getString("EmploiTempsConstructeurVue.classecompact");
		Stud1TablePanel = new ViewPanel(name);
		tabbedpane.add(name, Stud1TablePanel);

		name = getString("EmploiTempsConstructeurVue.salle");
		RoomTablePanel = new ViewPanel(name);
		tabbedpane.add(name, RoomTablePanel);

		tabbedpane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				switch (tabbedpane.getSelectedIndex()) {
				case 0:
					og = new GenerateurResultat("");
					og.SetData(getEDTData(), getGenerateurEDT());
					TchTablePanel.AddJCB(getJCB(EnsembeDonnees.TEACHER), og,getGenerateurEDT().isAllActivitiesPlace());
					TchTablePanel.setTable();
					break;
				case 1:
					og = new GenerateurResultat("");
					og.SetData(getEDTData(), getGenerateurEDT());
					StudTablePanel.AddJCB(getJCB(EnsembeDonnees.STUDENT), og,getGenerateurEDT().isAllActivitiesPlace());
					StudTablePanel.setTable();
					break;
				case 2:
					og = new GenerateurResultat("");
					og.SetData(getEDTData(), getGenerateurEDT());
					Stud1TablePanel.AddJCB(getJCB(0), og,getGenerateurEDT().isAllActivitiesPlace());
					Stud1TablePanel.setTable();
					break;
				case 3:
					og = new GenerateurResultat("");
					og.SetData(getEDTData(), getGenerateurEDT());
					RoomTablePanel.AddJCB(getJCB(EnsembeDonnees.ROOM), og,getGenerateurEDT().isAllActivitiesPlace());
					RoomTablePanel.setTable();
					break;
				default:
					break;
				}
			}
		});
	}

	public JComboBox getJCB(int c) {
		JComboBox jcb = new JComboBox();
		switch (c) {
		case EnsembeDonnees.TEACHER:
			jcb.setName("TEACHER");
			if (getEDTData().getPROFTaille() == 0)
				jcb.addItem("Pas de professeur");
			else
				jcb.addItem("Selectionner un professeur");
			for (int i = 0; i < getEDTData().getPROFTaille(); i++)
				jcb.addItem(getEDTData().getNomProf().get(i));
			break;
		case EnsembeDonnees.STUDENT:
			jcb.setName("STUDENT");
			if (getEDTData().getLongueurClasse() == 0)
				jcb.addItem("Pas de classe");
			else
				jcb.addItem("Selectionner classe");
			for (int i = 0; i < getEDTData().getLongueurTouteCLasses(); i++)
				jcb.addItem(getEDTData().getNomClasse().get(i));
			break;
		case EnsembeDonnees.ROOM:
			jcb.setName("ROOM");
			if (getEDTData().getLongueurSalle() == 0)
				jcb.addItem("Pas de salle");
			else
				jcb.addItem("choisir une classe");
			for (int i = 0; i < getEDTData().getLongueurSalle(); i++)
				jcb.addItem(getEDTData().getNomSalle().get(i));
			break;
		case 0:
			jcb.setName("STUDENT1");
			int StudLen=getEDTData().getLongueurClasse();
			if (StudLen == 0)
				jcb.addItem("Pas de classe");
			else
				jcb.addItem("Selectionner classe");
			for (int i = 0; i < StudLen; i++)
				jcb.addItem(getEDTData().getClasse(i).getNom());
			break;
		}
		return jcb;
	}

	public void actionPerformed(ActionEvent e) {
	}

}

class ViewPanel extends JPanel {
	private GenerateurResultat og;
	private boolean isGenerate;
	private JScrollPane tableAggregate;
	private JPanel tablePanel, headPanel;
	private JComboBox jcb;
	private String title;
	private int whichTable;
	private JTable tabView;
	private JLabel jta;
	public ViewPanel(String title) {
		super();
		this.title = title;
		tableAggregate = new JScrollPane();
		jta=new JLabel();
		jta.setText("- Pas encore sélectionné -");
		addViewPanel();
	}

	private void addViewPanel() {
		setBackground(Color.WHITE);
		setLayout(new BorderLayout());

		headPanel = new JPanel();
		headPanel.setLayout(new GridLayout(1, 2, 10, 10));
		headPanel.setBackground(Color.WHITE);
		headPanel.add(jta);

		tablePanel = new JPanel();
		tablePanel.setLayout(new GridLayout(1, 1, 10, 10));
		tablePanel.setBackground(Color.DARK_GRAY);
		tablePanel.add(tableAggregate);

		add(headPanel, BorderLayout.NORTH);
		add(tablePanel, BorderLayout.CENTER);
		updateUI();
	}

	public void setTable() {
		JScrollPane jspane;
		tabView=og.getEmploiTemps(-1, 0);
		jspane = new JScrollPane(tabView);
		tableAggregate=jspane;
		RefreshTable();
		tabView.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent arg0) {
			}
			public void mouseEntered(MouseEvent arg0) {
			}
			public void mouseExited(MouseEvent arg0) {
			}
			public void mousePressed(MouseEvent arg0) {
			}
			public void mouseReleased(MouseEvent arg0) {
				int r=tabView.getSelectedRow();
				int c=tabView.getSelectedColumn();
				String str=tabView.getValueAt(r, c).toString();
				if(c>0)
				jta.setText(str);
			}} );
	}

	public void RefreshTable() {
		tablePanel.removeAll();
		tablePanel.add(tableAggregate);
		tablePanel.updateUI();
	}

	public void AddJCB(JComboBox jcb_, GenerateurResultat og_, boolean isGenerate_) {
		jcb = jcb_;
		og=og_;
		isGenerate=isGenerate_;
		
		headPanel.removeAll();
		headPanel.add(jcb);
		headPanel.add(jta);
		headPanel.updateUI();

		if (jcb.getName().equals("TEACHER"))
			whichTable = EnsembeDonnees.TEACHER;
		if (jcb.getName().equals("STUDENT"))
			whichTable = EnsembeDonnees.STUDENT;
		if (jcb.getName().equals("STUDENT1"))
			whichTable = 0;
		if (jcb.getName().equals("ROOM"))
			whichTable = EnsembeDonnees.ROOM;

		jcb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(isGenerate){
					JScrollPane jspane;
					tabView=og.getEmploiTemps(jcb.getSelectedIndex()-1, whichTable);
					jspane = new JScrollPane(tabView);
					tableAggregate=jspane;
					RefreshTable();
					tabView.addMouseListener(new MouseListener(){
						public void mouseClicked(MouseEvent arg0) {
						}
						public void mouseEntered(MouseEvent arg0) {
						}
						public void mouseExited(MouseEvent arg0) {
						}
						public void mousePressed(MouseEvent arg0) {
						}
						public void mouseReleased(MouseEvent arg0) {
							int r=tabView.getSelectedRow();
							int c=tabView.getSelectedColumn();
							String str=tabView.getValueAt(r, c).toString();
							if(c>0)
							jta.setText(str);
						}} );
				}else
					setTable();
			}
		});
	}
}
