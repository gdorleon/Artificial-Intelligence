package gui;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.io.File;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.util.ArrayList;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import javax.swing.filechooser.FileFilter;

import donnees.LireFichierXML;
import donnees.XMLParseurSauvegarde;
import structdonnees.EnsembeDonnees;
import emploitemps.GenerateurResultat;
import emploitemps.CreerEDT;



public class PrincipalGUI extends JPanel {
	static PrincipalGUI principalGUI;
  
	EnsembeDonnees MAIN;
	
	private EDTModule currentMenu = null;
	private JPanel menuPanel = null;
	private JPanel pan01 = null;

	
	String opfichier="";
	JLabel stats = new JLabel("");
    boolean viewDS, ShowDS;
	GenerateurResultat rgen;
	LireFichierXML lfm01;
	XMLParseurSauvegarde xme01;
	JFileChooser jf01;
	CreerEDT edtc;
	File dir,xdir;
	
	boolean existingF, FileEnrg;


	private ArrayList<EDTModule> menuList = new ArrayList<EDTModule>();

	
	
	private JTextField statusField = null;

	
	private ToggleButtonToolBar toolbar = null;
	private ButtonToolBar btntoolbar = null;
	private ButtonGroup toolbarGroup = new ButtonGroup();

	
	private JFrame frame = null;



	
	private static final int PREFERRED_WIDTH = 800;
	private static final int PREFERRED_HEIGHT = 600;

	
	private ResourceBundle rsb01 = null;

	private boolean dragme = false;

	/**
	 * PrincipalGUI, the main application
	 */
	public static void main(String[] args) {

		JDialog.setDefaultLookAndFeelDecorated(true);
		JFrame.setDefaultLookAndFeelDecorated(true);

		UIManager.put("swing.boldMetal", Boolean.FALSE);
		principalGUI = new PrincipalGUI();

		principalGUI.afficherEDT();

	}

	/**
	 * PrincipalGUI Constructor
	 */

	public PrincipalGUI() {

		String tp="";

		existingF = false;
		FileEnrg = false;
		
		dir = new File(tp+"Baseconnaissance");
		if (!dir.isDirectory())	if (dir.mkdir()) {}
		xdir = new File(dir.getPath()+"/XML");
		if (!xdir.isDirectory()) if (xdir.mkdir()){}
		
	
        
		MAIN = new EnsembeDonnees();
		xme01 = new XMLParseurSauvegarde();
		edtc = new CreerEDT();

		frame = createFrame();

		setLayout(new BorderLayout());


		setPreferredSize(new Dimension(PREFERRED_WIDTH, PREFERRED_HEIGHT));

		initializepmenu();
		
		initFileChooser();
	}

	




	/**
	 * ramener l'application en affichant le frame
	 */

	public void afficherEDT() {
		JFrame f = getFrame();
		f.setTitle(getString("Frame.title"));
		f.getContentPane().add(this, BorderLayout.CENTER);
		f.pack();
		Rectangle screenRect = f.getGraphicsConfiguration().getBounds();
		Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(
				f.getGraphicsConfiguration());

		// se rassurer que l'interface n'est pas placée hors de l'écran
		
		int centerWidth = screenRect.width < f.getSize().width ? screenRect.x
				: screenRect.x + screenRect.width / 2 - f.getSize().width / 2;
		int centerHeight = screenRect.height < f.getSize().height ? screenRect.y
				: screenRect.y + screenRect.height / 2 - f.getSize().height / 2;

		centerHeight = centerHeight < screenInsets.top ? screenInsets.top : centerHeight;

		f.setLocation(centerWidth, centerHeight);
		f.setVisible(true);
	}


	/**
	 * Charger les démos depuis une liste de démos
	 */
	void chargerMenus() {
		
		
			chargerMenu("DataInput");
			chargerMenu("EmploiTempsConstructeurVue");
	
	}

	/**
	 * Enlever toutes les démos de la liste des démos et charger la première démo
	 */
	void unloadmenus() {
		menuList.clear();
		toolbar.removeAll();
		toolbar.updateUI();
		preloadFirstMenu();
	}

	/**
	 * Charger un menu à l'aide du nom de la classe
	 */
	void chargerMenu(String classname) {
		EDTModule tmenu = null;
		try {
			Class menupcl = Class.forName("gui." + classname);
			Constructor amenuConstructor = menupcl.getConstructor(new Class[] { PrincipalGUI.class });
			tmenu = (EDTModule) amenuConstructor.newInstance(new Object[] { this });
			ajouterMenu(tmenu);

		} catch (Exception e) {
			System.out.println("Erreur lors du chargement des données de démo: " + classname);
		}
	}

	/**
	 * Ajouter un menu à la liste des menus
	 */
	public EDTModule ajouterMenu(EDTModule bmenu) {
		menuList.add(bmenu);
		if (dragme) {
			bmenu.updateDragEnabled(true);
		}


		SwingUtilities.invokeLater(new edtsetup(this, bmenu) {
			public void run() {

				SwitchToMenuAction action = new SwitchToMenuAction(principalGUI,(EDTModule) obj);
				JToggleButton tb = principalGUI.getToggleButtonToolBar().addToggleButton(action);
				principalGUI.getToolBarGroup().add(tb);
				if (principalGUI.getToolBarGroup().getSelection() == null) {
					tb.setSelected(true);
					tb.setBackground(new Color(200, 187, 255, 200));
				}
				tb.setBackground(new Color(205, 255, 155, 155));
				
			}
		});
		return bmenu;
	}

	/**
	 * Charger la première menu.ceci est fait séparément des autres menus
	 * ainsi le logiciel peux être disponible aux utilisateur de manière très rapide
	 */
	public void preloadFirstMenu() {
		EDTModule cmenu = ajouterMenu(new DataInputPanel(this));
		setMenu(cmenu);
	}

	/**
	 * charger les autres ménus
     */
	public void initializepmenu() {

		JPanel top = new JPanel();
		top.setLayout(new BorderLayout());
		add(top, BorderLayout.NORTH);

		ToolBarPanel toolbarPanel = new ToolBarPanel();
		toolbar = new ToggleButtonToolBar();
		btntoolbar = new ButtonToolBar();
		toolbarPanel.setLayout(new BorderLayout());
		toolbarPanel.add(toolbar, BorderLayout.CENTER);
		top.add(toolbarPanel, BorderLayout.SOUTH);
		toolbarPanel.addContainerListener(toolbarPanel);

		menuPanel = new JPanel();
		menuPanel.setLayout(new BorderLayout());
		menuPanel.setBorder(new EtchedBorder());
		add(menuPanel, BorderLayout.CENTER);

		pan01 = new JPanel();
		pan01.setLayout(new BorderLayout());
		add(pan01, BorderLayout.EAST);

		statusField = new JTextField("");
		statusField.setEditable(false);
		add(statusField, BorderLayout.SOUTH);
chargerMenus();//
	}

	/**
	 * Choisir un  menu comme menu courante
	 */
	public void setMenu(EDTModule fmenu) {
	
		setTitle(getString("Frame.title") +" >>"+ opfichier);
		currentMenu = fmenu;
		
		
		JComponent currentMenuPanel = fmenu.getMenuPanel();
		SwingUtilities.updateComponentTreeUI(currentMenuPanel);

		btntoolbar.setVisible(false);
		menuPanel.removeAll();
		pan01.removeAll();
		btntoolbar.updateUI();
		SwingUtilities.updateComponentTreeUI(menuPanel);
		menuPanel.add(currentMenuPanel, BorderLayout.CENTER);
		getSideButtonPanel(fmenu);
	}

	public void getSideButtonPanel(EDTModule smeu) {

		ToolBarPanel toolbarsidePanel = new ToolBarPanel();
		btntoolbar = new ButtonToolBar();
		btntoolbar.setOrientation(ButtonToolBar.VERTICAL);
		
		if (smeu.getName().equals("DataInput")) {
			btntoolbar.addButton("Nouveau", "Nouveau.png");
			btntoolbar.addButton("Ouvrir", "Ouvrir.png");
			btntoolbar.addButton("Enregistrer", "Enregistrer.png");
			btntoolbar.addButton("Fermer", "Fermer.png");
		}
		if (smeu.getName().equals("EmploiTempsConstructeurVue")) {// "EmploiTempsConstructeurVue"
			btntoolbar.addButton("Generer l'emploi du temps", "");
			btntoolbar.addButton("Fermer", "");
		}
		toolbarsidePanel.setLayout(new BorderLayout());
		toolbarsidePanel.add(btntoolbar, BorderLayout.CENTER);
		pan01.add(toolbarsidePanel, BorderLayout.NORTH);
		toolbarsidePanel.addContainerListener(toolbarsidePanel);
	}

	
	public void initFileChooser(){
		jf01 = new JFileChooser();
		jf01.setCurrentDirectory(xdir);
		jf01.setFileFilter(new FileFilter() {
			public boolean accept(File f) {
				return f.getName().toLowerCase().endsWith(XMLParseurSauvegarde.ext) || f.isDirectory();
			}
			public String getDescription() {
				return "PrincipalGUI (XML) Files";
			}
		});
	}
	/**
	 * Retourne une instance de frame
	 */
	public JFrame getFrame() {
		return frame;
	}

	/**
	 * créer un frame qui contiendra l'application
	 */
	public static JFrame createFrame() {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return frame;
	}

	/**
	 * Modifier le titre
	 */
	public void setTitle(String s) {
		
		// faire ceci au thread utilisateur
		SwingUtilities.invokeLater(new edtsetup(this, s) {
			public void run() {
				principalGUI.frame.setTitle((String) obj);
			}
		});
	}

	/**
	 * Modifier le status
	 */
	public void setStatus(String s) {

		SwingUtilities.invokeLater(new edtsetup(this, s) {
			public void run() {
				principalGUI.statusField.setText((String) obj);
			}
		});
	}

	/**
	 * retouner le toolbar
	 */
	public ToggleButtonToolBar getToggleButtonToolBar() {
		return toolbar;
	}

	/**
	 * retourner le groupe de boutons du toolbar
	 */
	public ButtonGroup getToolBarGroup() {
		return toolbarGroup;
	}

	/**
	 * retourne une valeur de la ressource
	 */
	public String getString(String key) {
		String value = null;
		try {
			value = getResourceBundle().getString(key);
		} catch (MissingResourceException e) {
			System.out
					.println("java.util.MissingResourceException: Couldn't find value for: "
							+ key);
		}
		if (value == null) {
			value = "Could not find resource: " + key + "  ";
		}
		return value;
	}

	/**
	 * retourne le bundle associé à cette ressource, utilisée pour l'internationalisation des chaines de caractères
	 */
	public ResourceBundle getResourceBundle() {
		if (rsb01 == null) {
			rsb01 = ResourceBundle.getBundle("resources.edt");
		}
		return rsb01;
	}

	/**
	 * retournes les raccourcis clavier qui seront utilisés pour accéder au  menu de l'application
	 */
	public char getMnemonic(String key) {
		return (getString(key)).charAt(0);
	}

	/**
	 * créer une image contenue dans le dossier images
	 */
	public ImageIcon createImageIcon(String filename, String description) {
		String path = "/resources/images/" + filename;
		return new ImageIcon(this.getClass().getResource(path));
	}

	// *******************************************************

	static Insets tptinseme = new Insets(1, 1, 1, 1);

	protected class ToggleButtonToolBar extends JToolBar {
		public ToggleButtonToolBar() {
			super();
		}

		JToggleButton addToggleButton(Action a) {
			JToggleButton tb = new JToggleButton((String) a
					.getValue(Action.NAME), (Icon) a
					.getValue(Action.SMALL_ICON));
			tb.setMargin(tptinseme);
			tb.setText(null);
			tb.setEnabled(a.isEnabled());
			tb.setToolTipText((String) a.getValue(Action.SHORT_DESCRIPTION));
			tb.setAction(a);
			add(tb);
			return tb;
		}

	}

	protected class ButtonToolBar extends JToolBar {
		public ButtonToolBar() {
			super();
		}

		JButton addButton(String name, String icon_name) {
			JButton tb = new JButton(name, createImageIcon(icon_name, ""));
			tb.setMargin(tptinseme);
			tb.setBorderPainted(false);
			tb.setText(name);
			tb.setToolTipText(name);
			if (name.contains("Fermer")) {
				tb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if(opfichier!="")
						if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
							"Voulez vous fermer le fichier "+opfichier, "Fermer!!!",JOptionPane.YES_NO_OPTION))
							CLOSEFILE();
						setTitle(getString("Frame.title") +" >>"+ opfichier);
					}
				});
			} else if (name.contains("Nouveau")) {
				tb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						CREATEFILE();
						setTitle(getString("Frame.title") +" >>"+ opfichier);
					}
				});
			} else if (name.contains("Ouvrir")) {
				tb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						OPENFILE();
						setTitle(getString("Frame.title") +" >>"+ opfichier);
					}
				});
			} else if (name.contains("Enregistrer")) {
				tb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						SAVEFILE();
					}
				});
			} else if (name.contains("Generer")) {
				tb.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
		
						if (edtc.isActivitiesGenerated()) {
							edtc.MainAlgo(principalGUI.getFrame());
						} else
							JOptionPane.showMessageDialog(null,"Générer d'abord les activités!");

					}
				});
			}
			add(tb);
			return tb;
		}

	}



	class ToolBarPanel extends JPanel implements ContainerListener {

		public boolean contains(int x, int y) {
			Component c = getParent();
			if (c != null) {
				Rectangle r = c.getBounds();
				return (x >= 0) && (x < r.width) && (y >= 0) && (y < r.height);
			} else {
				return super.contains(x, y);
			}
		}

		public void componentAdded(ContainerEvent e) {
			Container c = e.getContainer().getParent();
			if (c != null) {
				c.getParent().validate();
				c.getParent().repaint();
			}
		}

		public void componentRemoved(ContainerEvent e) {
			Container c = e.getContainer().getParent();
			if (c != null) {
				c.getParent().validate();
				c.getParent().repaint();
			}
		}
	}


	class edtsetup implements Runnable {
		protected PrincipalGUI principalGUI;
		protected Object obj;

		public edtsetup(PrincipalGUI principalGUI, Object obj) {
			this.principalGUI = principalGUI;
			this.obj = obj;
		}

		public void run() {
		}
	}

	public class SwitchToMenuAction extends AbstractAction {
		PrincipalGUI principalGUI;
		EDTModule smenu;

		public SwitchToMenuAction(PrincipalGUI principalGUI, EDTModule menu) {
			super(menu.getName(), menu.getIcon());
			this.principalGUI = principalGUI;
			this.smenu = menu;
		}

		public void actionPerformed(ActionEvent e) {
			principalGUI.setMenu(smenu);
		}
	}


	
	public void CLOSEFILE() {
		MAIN = new EnsembeDonnees();
		xme01 = new XMLParseurSauvegarde();
		edtc.SetData(MAIN);
		existingF = false;
		FileEnrg = false;
		opfichier="";
		
		if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
			"Voulez vous quitter?"+opfichier, "Quitter!!!",JOptionPane.YES_NO_OPTION))
				System.exit(0);
		
	}

	public void CREATEFILE() {
		if (!existingF && !FileEnrg && opfichier=="") {
			MAIN = new EnsembeDonnees();
			xme01 = new XMLParseurSauvegarde();
			edtc.SetData(MAIN);
			xme01.newXEDTM();
			existingF = true;
			opfichier=new File(xdir.getPath()+"/temp"+XMLParseurSauvegarde.ext).getPath();
 		    jf01.setSelectedFile(new File(opfichier));
		} else if (opfichier!=""){
			JOptionPane.showMessageDialog(null,"Fermer d'abord ! \nImpossible de créer un nouveau fichier", 
					"Erreur création nouveau fichier",JOptionPane.ERROR_MESSAGE);
		}else if (!FileEnrg){
			JOptionPane.showMessageDialog(null,"Sauvegarder d'abord ! \nImpossible de créer un nouveau fichier", 
					"Erreur création nouveau fichier",JOptionPane.ERROR_MESSAGE);
		}
	}

	public void OPENFILE() {
		String openFile;
		if (opfichier=="") {
			int returnVal = jf01.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				openFile = jf01.getSelectedFile().getPath();
				if (isXmlFileExist(openFile)) {
					lfm01 = new LireFichierXML(principalGUI);
					opfichier = openFile;
					lfm01.readData(openFile);
					edtc.SetData(MAIN);
					setMenu(new DataInput(principalGUI));
				} else {
					JOptionPane.showMessageDialog(null, "Impossible d'ouvrir un nouveau fichier :"	+ openFile, 
							"Erreur ouverture de fichier",JOptionPane.ERROR_MESSAGE);
				}
			}
		}else {
			JOptionPane.showMessageDialog(null, "Fermer le fichier ouvert :"	+ opfichier, 
					"Fermer d'abord le fichier",JOptionPane.ERROR_MESSAGE);
		}
		principalGUI.updateUI();
	}

	public void SAVEFILE() {
		String saveFile;
		if (existingF && !FileEnrg) {
			int returnVal = jf01.showSaveDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				saveFile = jf01.getSelectedFile().getPath();
				xme01.SaveKB(saveFile, MAIN);
				FileEnrg = true;
			    MAIN.setStatus(true);
			    JOptionPane.showMessageDialog(null, "Fichier enregistré avec succès"	, 
						"Fichier enregistré",JOptionPane.INFORMATION_MESSAGE);
			}
		}else if (!MAIN.getStatus() && opfichier!=""){
			xme01.newXEDTM();
			xme01.SaveKB(opfichier, MAIN);
			FileEnrg = true;
		    MAIN.setStatus(true);
		    JOptionPane.showMessageDialog(null, "Fichier enregistré avec succès!"	, 
					"Saved File",JOptionPane.INFORMATION_MESSAGE);
		}else if (opfichier==""){
			JOptionPane.showMessageDialog(null, "aucun fichier ouvert"	, 
					"Erreur enregistrement de fichier",JOptionPane.ERROR_MESSAGE);
		}			
	}

	public boolean isXmlFileExist(String xmlfile) {
		return (new File(xmlfile).exists());
	}

	
}
