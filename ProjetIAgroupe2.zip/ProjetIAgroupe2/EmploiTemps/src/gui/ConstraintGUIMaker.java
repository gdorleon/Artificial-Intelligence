package gui;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import structdonnees.EnsembeDonnees;
import structdonnees.Matrice2D;

/**
 * 
 * @author gervais Cette classe représente l'interface qui permet de configurer
 *         les contraintes hard et soft. Les intitullé des contrainte sont dans
 *         un fichier property et celui-ci est chargé pour retrouver les
 *         contenus et afficher dans l'interface
 */
public class ConstraintGUIMaker extends EDTModule {
	JComboBox box1;
	JComboBox box2;
	JScrollPane banc1;
	JPanel box3;
	JTable box4;
	JTextField text1;
	
	Vector<String> List1, List2;
	String princip, choixroom, etuchx;
	int i, start, etustart;
	
	Matrice2D<Boolean> EmploiDuTemps;

	String[] lJours = { "Heure\\Jour", "Lundi", "Mardi", "Mercredi", "Jeudi",
			"Vendredi" };
	String[] lHeures = { "Heure 1:", "Heure 2:", "Heure 3:", "Heure 4:", "Heure 5:",
			"Heure 6:", "Heure 7:", "Heure 8:" };

	

	public ConstraintGUIMaker(PrincipalGUI principalGUI, String rule) {
		super(principalGUI);
		this.princip = rule;
	}

	public JPanel getPanel(int i_) {
		JPanel rulePanel = new JPanel();

		this.i = i_;
		String DEFAULT[] = {
				"<br> ",
				"<br> ",
				"<br> contrainte hard non modifiable",
				"<br> contrainte hard non modifiable",
				"<br> contrainte hard non modifiable",
				"<br> contrainte hard non modifiable",
				"<br> contrainte hard non modifiable",
				"<br> contrainte hard non modifiable",
				"<br> Na",
				"<br> Au moins 'n' jours entres une meme activité : 1 jour",
				"<br> Na",
				"<br> Na",
				"<br> Na",
				"<br> Toutes les salles sont disponibles pour toutes les classes",
				"<br> 	Tous les laboratoires sont disponibles pour les classes" };

		box1 = new JComboBox();
		box2 = new JComboBox();
		banc1 = new JScrollPane();
		box3 = new JPanel();
		JButton set;
		JPanel jpo = new JPanel();
		jpo.setLayout(new BorderLayout());

		JPanel jp = new JPanel();
		jp.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(2, 0, 2, 0);
		gbc.anchor = GridBagConstraints.CENTER;
		switch (i) {
		case 0:
			text1 = new JTextField();
			text1.setColumns(20);
			text1.setText("Nom de l'université");
			set = new JButton("Enregistrer nom ");
			set.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String str = text1.getText();
					if (!str.equals(null)) {
						getEDTData().getContrainte().setUniversite(str);
						JOptionPane.showMessageDialog(null,
								"Nom de l'université enregistré avec!");
					} else
						JOptionPane.showMessageDialog(null,
								"Nom de l'université ne contient rien!!");
				}
			});

			gbc.gridx = 1;
			gbc.gridy = 1;
			jp.add(text1, gbc);
			gbc.gridx = 20;
			jp.add(set, gbc);

			jpo.add(jp, BorderLayout.NORTH);
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>Par défaut à : : "
					+ getEDTData().getContrainte().getCollageName() + "<hr></html>"),
					BorderLayout.SOUTH);

			break;
		case 1:
			text1 = new JTextField();
			text1.setColumns(20);
			text1.setText("Nom du département");
			set = new JButton("Enregistrer ");
			set.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String str = text1.getText();
					if (!str.equals(null)) {
						getEDTData().getContrainte().setDepartement(str);
						JOptionPane.showMessageDialog(null,
								"Nom du département modifié!");
					} else
						JOptionPane.showMessageDialog(null,
								"Le nom de département est vide !");
				}
			});

			gbc.gridx = 1;
			gbc.gridy = 1;
			jp.add(text1, gbc);
			gbc.gridx = 20;
			jp.add(set, gbc);

			jpo.add(jp, BorderLayout.NORTH);
			
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>Par l'utilisateur mis à : "
					+ getEDTData().getContrainte().getDeptName() + "<hr></html>"),
					BorderLayout.SOUTH);

			break;
		case 8:
			set = new JButton("reserver pause");
			set.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String str = List1.get(box1.getSelectedIndex());
					getEDTData().getContrainte().setPause(str);
					JOptionPane.showMessageDialog(null,
							"Pause allouée avec succès!");
				}
			});

			List1 = getList(EnsembeDonnees.TIME);
			box1.removeAll();
			box1.setModel(new DefaultComboBoxModel(List1));

			gbc.gridx = 1;
			gbc.gridy = 1;
			jp.add(box1, gbc);
			gbc.gridx = 20;
			jp.add(set, gbc);

			jpo.add(jp, BorderLayout.NORTH);
			
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>By User set to : "
					+ getEDTData().getContrainte().getBreak() + "<hr></html>"),
					BorderLayout.SOUTH);

			break;
		case 10:
			set = new JButton("Set Contrainte");
			List1 = getList(EnsembeDonnees.TEACHER);
			box1.removeAll();
			box1.setModel(new DefaultComboBoxModel(List1));
			box1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					start = box1.getSelectedIndex() - 1;
					setTable(start, EnsembeDonnees.TEACHER);
				}
			});
			set.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (start != -1) {
						getEDTData().getContrainte().getTeacher()
								.set2DPart(start, EmploiDuTemps);
						JOptionPane.showMessageDialog(null,
								"Contrainte attribuée!");
					} else {
						JOptionPane.showMessageDialog(null,
								"Selectionner d'abord le professeur! ");
					}
				}
			});

			gbc.gridx = 1;
			gbc.gridy = 1;
			jp.add(box1, gbc);
			gbc.gridx = 20;
			jp.add(set, gbc);

			gbc.gridx = 1;
			gbc.gridy = 30;
			box3.add(banc1);

			jpo.add(jp, BorderLayout.NORTH);
			jpo.add(box3, BorderLayout.CENTER);
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>Utilisateur mis à : " + DEFAULT[i] + "<hr></html>"),
					BorderLayout.SOUTH);

			break;
		case 11:
			set = new JButton("Set Contrainte");
			List1 = getList(EnsembeDonnees.STUDENT);
			box1.removeAll();
			box1.setModel(new DefaultComboBoxModel(List1));
			box1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					start = box1.getSelectedIndex() - 1;
					int s = -1;
					if (start != -1) {
						s = getGenerateurEDT().searchStudent(
								box1.getSelectedItem().toString());
						setTable(s, EnsembeDonnees.STUDENT);
					}
				}
			});
			set.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (start != -1) {
						int s = getGenerateurEDT().searchStudent(
								box1.getSelectedItem().toString());
						int size = s
								+ getEDTData().getClasse(start)
										.getListeGroupe().size();
						for (; s < size + 1; s++)
							getEDTData().getContrainte().getStudent()
									.set2DPart(s, EmploiDuTemps);
						JOptionPane.showMessageDialog(null,
								"Contrainte prise en compte!");
					} else {
						JOptionPane.showMessageDialog(null,
								"Selectioner d'abord l'étudiant! ");
					}
				}
			});

			gbc.gridx = 1;
			gbc.gridy = 1;
			jp.add(box1, gbc);
			gbc.gridx = 20;
			jp.add(set, gbc);

			gbc.gridx = 1;
			gbc.gridy = 30;
			box3.add(banc1);

			jpo.add(jp, BorderLayout.NORTH);
			jpo.add(box3, BorderLayout.CENTER);
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>Par défaut à :" + DEFAULT[i] + "<hr></html>"),
					BorderLayout.SOUTH);
			break;
		case 12:
			set = new JButton("Set Contrainte");
			List1 = getList(EnsembeDonnees.ROOM);
			box1.removeAll();
			box1.setModel(new DefaultComboBoxModel(List1));
			box1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					start = box1.getSelectedIndex() - 1;
					setTable(start, EnsembeDonnees.ROOM);
				}
			});
			set.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (start != -1) {
						getEDTData().getContrainte().getRoom()
								.set2DPart(start, EmploiDuTemps);
						JOptionPane.showMessageDialog(null,
								"Contrainte prise en compte!");
					} else {
						JOptionPane.showMessageDialog(null,
								"Selectionner d'abord la salle! ");
					}
				}
			});

			gbc.gridx = 1;
			gbc.gridy = 1;
			jp.add(box1, gbc);
			gbc.gridx = 20;
			jp.add(set, gbc);

			gbc.gridx = 1;
			gbc.gridy = 30;
			box3.add(banc1);

			jpo.add(jp, BorderLayout.NORTH);
			jpo.add(box3, BorderLayout.CENTER);
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>Par défaut à :" + DEFAULT[i] + "<hr></html>"),
					BorderLayout.SOUTH);

			break;
		default:
			jpo.add(new JLabel("<html><hr>" + princip
					+ "<br><br>Par défaut à : " + DEFAULT[i]
					+ "<hr></html>"), BorderLayout.NORTH);
		}

		rulePanel.removeAll();
		rulePanel.add(jpo);
		rulePanel.updateUI();

		return rulePanel;
	}

	public Vector<String> getList(int c) {
		Vector<String> RVList = new Vector<String>();
		RVList.clear();
		switch (c) {
		case EnsembeDonnees.TEACHER:
			RVList.add(0, "choisir Professeur");
			for (int i = 1; i < getEDTData().getPROFTaille() + 1; i++)
				RVList.add(i, getEDTData().getProfesseur(i - 1).getNom());
			break;
		case EnsembeDonnees.STUDENT:
			RVList.add(0, "Choisir Classe");
			for (int i = 1; i < getEDTData().getLongueurClasse() + 1; i++)
				RVList.add(i, getEDTData().getClasse(i - 1).getNom());
			break;
		case EnsembeDonnees.ROOM:
			RVList.add(0, "Choisir Salle");
			for (int i = 1; i < getEDTData().getLongueurSalle() + 1; i++)
				RVList.add(i, getEDTData().getSalle(i - 1).getNom());
			break;
		case EnsembeDonnees.TIME:
			RVList.add(0, "Choisir Créneaux");
			for (int i = 1; i < getEDTData().getCreneaux().getHeure().size() + 1; i++)
				RVList.add(i, getEDTData().getCreneaux().getHeure().get(i - 1));
			break;
		}
		return RVList;
	}

	public void RefreshTable() {
		JScrollPane jpane;
		jpane = new JScrollPane(getTimeslotTable());
		banc1 = jpane;

		box3.removeAll();
		box3.add(banc1);
		box3.updateUI();
	}

	public void setTable(int i, int which) {
		if (i == -1) {

		} else {
			switch (which) {
			case EnsembeDonnees.TEACHER:
				EmploiDuTemps = getEDTData().getContrainte().getTeacher().get2DPart(i);
				break;
			case EnsembeDonnees.STUDENT:
				EmploiDuTemps = getEDTData().getContrainte().getStudent().get2DPart(i);
				break;
			case EnsembeDonnees.ROOM:
				EmploiDuTemps = getEDTData().getContrainte().getRoom().get2DPart(i);
				break;
			}
		}
		RefreshTable();
	}

	public JTable getTimeslotTable() {
	
		TableModel dataModel = new AbstractTableModel() {
			public int getColumnCount() {
				return EmploiDuTemps.getp() + 1;
			}

			public int getRowCount() {
				return EmploiDuTemps.getn();
			}

			public Object getValueAt(int row, int col) {
				if (col == 0)
					return getEDTData().getCreneaux().getHeure().get(row);
				else
					return EmploiDuTemps.getData(row, col - 1);
			}

			public String getColumnName(int column) {
				if (column == 0)
					return "Heure\\Jour";
				else
					return getEDTData().getCreneaux().getJours().get(column - 1);
			}

			public Class getColumnClass(int c) {
				return getValueAt(0, c).getClass();
			}

			public boolean isCellEditable(int row, int col) {
				return row != -1;
			}

			public void setValueAt(Object aValue, int row, int column) {
				if (column > 0) {
					if (aValue.equals(true))
						EmploiDuTemps.setData(row, column - 1, true);
					else if (aValue.equals(false))
						EmploiDuTemps.setData(row, column - 1, false);
				}
			}
		};


		box4 = new JTable(dataModel);
		box4.setRowHeight(30);
		return box4;
	}
}
