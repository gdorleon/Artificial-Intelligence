package gui;

import javax.swing.*;
import javax.swing.event.*;

import structdonnees.EnsembeDonnees;

import java.awt.*;
import java.awt.event.*;

/**
 * Cette classe gère la recupération des données necessaires à la génération
 * d'un emploi du temps
 */
public class DataInput extends EDTModule implements ActionListener {
	JTabbedPane ptb1;
	ContraintePanel cp01;
	DataInputPanel ipd01;
	PanelActivite pap01;
	JPanel pj01;

	public DataInput(PrincipalGUI principalGUI) {
		super(principalGUI, "DataInput", "edm.png");

		ptb1 = new JTabbedPane();
		getMenuPanel().add(ptb1, BorderLayout.CENTER);

		// MEnu entrée de données

		String name = "Etape 1 >> " + getString("DataInput.dept");
		ipd01 = new DataInputPanel(principalGUI);
		ptb1.add(name, ipd01.getMasterPanel());

		// Menu activités
		
		
		name = "Etape 2 >> " + getString("DataInput.activite");
		pap01 = new PanelActivite(principalGUI);
		ptb1.add(name, pap01.getActivityPanel());
		
		
		// Menu contraintes
		
		
		name = "Etape 3 >> " + getString("DataInput.contrainte");
		cp01 = new ContraintePanel(principalGUI);
		ptb1.add(name, cp01.getContraintesPanel());

		
		
		
		ptb1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				if (ptb1.getSelectedIndex() == 1) {
					pap01.UploadListData(EnsembeDonnees.TEACHER);
					pap01.UploadListData(EnsembeDonnees.STUDENT);
					pap01.UploadListData(EnsembeDonnees.ROOM);
					pap01.UploadListData(EnsembeDonnees.SUBJECT);
					pap01.UploadListData(EnsembeDonnees.ACTIVITY);
					pap01.UploadListData(EnsembeDonnees.ASSIGNSUBJECT);
				}
			}
		});

	}

	public void actionPerformed(ActionEvent e) {

	}

}
