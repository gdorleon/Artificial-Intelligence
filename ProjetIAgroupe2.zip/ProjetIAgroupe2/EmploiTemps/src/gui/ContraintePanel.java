package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

/**
 * Internal Frames Menu
 */
public class ContraintePanel extends EDTModule {
	private JPanel contraintePanel, principalContraintePanel;
	private Vector<ShowHideContraintePanel> SHContraintePanel;	
	private ArrayList<ConstraintGUIMaker> rg;
	
	/**
	 * Construit l'ensemble des règles contenues ressources toutes les hards et les softs constraints
	 */
	public ContraintePanel(PrincipalGUI principalGUI) {
		super(principalGUI, "", "");

		rg=new ArrayList<ConstraintGUIMaker>();
		

		SHContraintePanel = new Vector<ShowHideContraintePanel>();
		principalContraintePanel = new JPanel();
		principalContraintePanel.setLayout(new BorderLayout());

		contraintePanel = new JPanel();
		contraintePanel.setLayout(new BoxLayout(contraintePanel, BoxLayout.PAGE_AXIS));

		for (int i = 0; i < 15; i++)
			SHContraintePanel.add(i, new ShowHideContraintePanel());
		
		for (int i = 0; i < 15; i++) {
			String contrainte = getString("Regles.regle" + String.valueOf(i+1));
			contraintePanel.add(SHContraintePanel.get(i).AddJCB(i+1,contrainte));
			contraintePanel.add(SHContraintePanel.get(i).AddContraintes(i+1,contrainte));
			contrainte=contrainte.replace("<html>", "").replace("</html>", "");
			rg.add(i, new ConstraintGUIMaker(principalGUI,contrainte));
		}
		JScrollPane tmp = new JScrollPane(contraintePanel);
		JPanel temp = new JPanel();
		temp.add(new JLabel(getString("Regles.description")));
		principalContraintePanel.add(temp,BorderLayout.NORTH);
		principalContraintePanel.add(tmp,BorderLayout.CENTER);
	}

	public JPanel getContraintesPanel() {
		return principalContraintePanel;
	}
	
	class ShowHideContraintePanel {
		JPanel p, p1, p2;
		JCheckBox jcbContrainte;

		public ShowHideContraintePanel() {
			p = new JPanel();
			p1 = new JPanel();
			p2 = new JPanel();
		}

		public JPanel AddJCB(int i,String rule) {
			final int ci =i-1;
			jcbContrainte = new JCheckBox(rule);
			p.setLayout(new GridLayout());
			p.add(jcbContrainte, BorderLayout.LINE_START);
			jcbContrainte.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (jcbContrainte.isSelected())
						afficherPanel(ci);
					else
						cacherPanel(ci);
				}
			});
			if(i>2 && i<11)
				jcbContrainte.setToolTipText("<html>Contraintes rigides par défaut& Contraintes souples</html>");
			if(i>10 && i<14)
				jcbContrainte.setToolTipText("<html>Contraintes optionnelles</html>");
			if(i>13 && i<16)
				jcbContrainte.setToolTipText("<html>Contraintes souples par défaut</html>");
			
			return p;
		}

		public JPanel AddContraintes(int i,String rule) {
			p1.setLayout(new BorderLayout());
			p2.setLayout(new BorderLayout());
			p2.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
			p2.add(new JLabel(rule), BorderLayout.LINE_START);
			return p1;
		}

		public void afficherPanel(int i) {
			p2.removeAll();
			p2.add(rg.get(i).getPanel(i), BorderLayout.CENTER);
			p2.updateUI();
			p1.add(p2);
			p1.updateUI();
		}

		public void cacherPanel(int i) {
			p1.remove(p2);
			p1.updateUI();
		}
	}

}
